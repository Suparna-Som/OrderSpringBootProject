public class Student {
    public String StId;
        public String StName;
        public String StCity;

    public String getID() {
        return StId;
    }
    public void setID(String  newID) {
        this.StId = newID;
    }
        public String getName() {
            return StName;
        }
        public void setName(String newName) {
            this.StName = newName;
        }
    public String getCity() {
        return StCity;
    }
    public void setCity(String  newCity) {
        this.StCity = newCity;
    }

    }

